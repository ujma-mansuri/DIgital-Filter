# program: Clipping_Filter.py
# author: Ujma Mansuri
# student ID: 200398136
# course: CS 827
# date:  16th November, 2018
# description: This program reads a mysteryTones.dat file with space 
#              delimited PCM data and after this applies a user defined filter(Clipping filter)/Distortion effect and write the output to a out.dat file. 


import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import random
import math
import matplotlib.pyplot as plt

#read the mysteryTones.dat file
data = pd.read_csv("E:/Semester 3/Computer Audio/Assignment/mysteryTones.dat", header=None, delimiter=r"\s+")

x = data[0]
y = data[1]
xlist = []
ylist = []

# populate the lists with the contents of the columns read
for i in range(0,int(len(x))):
   xlist.append(float(x.iloc[i]))
   ylist.append(float(y.iloc[i]))   

f = open("out.dat", "w")

# this will add header required for pcm formated file, because I have removed it from "mysteryTines.dat" file

f.write("; Sample Rate "+str(44100)+"\n")
f.write("; Channels 1"+"\n")

# clipping filter/distortion effect
threshold= 0.05 # max amplitude value from which you want to clip the signal
#loop through whole data
for i in range(0,int(len(xlist))):
	if ylist[i]>threshold: # check if amplitude above threshold cut the signal to the threshold value
		ylist[i]=threshold
		f.write(str(xlist[i])+"   "+str(((ylist[i]))))
	elif ylist[i]<(-threshold): # check if amplitude below (-threshold) cut the signal to the threshold value
		ylist[i]=(-threshold)
		f.write(str(xlist[i])+"   "+str(((ylist[i]))))
	else:
		f.write(str(xlist[i])+"   "+str(((ylist[i]))))

f.close() 
